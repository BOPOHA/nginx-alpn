
/*
 * Copyright (C) Dmitry Volyntsev
 * Copyright (C) NGINX, Inc.
 */


#ifndef _NJS_EXTERNAL_WEBCRYPTO_H_INCLUDED_
#define _NJS_EXTERNAL_WEBCRYPTO_H_INCLUDED_


njs_int_t njs_external_webcrypto_init(njs_vm_t *vm);


#endif /* _NJS_EXTERNAL_WEBCRYPTO_H_INCLUDED_ */
