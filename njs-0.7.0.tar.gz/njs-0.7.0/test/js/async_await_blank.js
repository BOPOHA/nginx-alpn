async function af(x) {
    return x;
}

af(12345).then(v => console.log(v));
