var argv = process.argv.slice(2);
console.log(argv[0] + argv[1])
